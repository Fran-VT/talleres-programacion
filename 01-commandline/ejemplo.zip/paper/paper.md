---
title: Como sobrevir cuarnetenas reinventandose como ingeniero en software
subtitle: Una estrategia para salud mental y futura salud economica
---
